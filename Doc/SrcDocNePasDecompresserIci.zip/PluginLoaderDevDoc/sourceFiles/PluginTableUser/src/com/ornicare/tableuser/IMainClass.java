package com.ornicare.tableuser;

public interface IMainClass {

}