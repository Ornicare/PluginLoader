package com.ornicare.helloworld;

import cconsole.CConsole;

import com.space.annotations.LaunchInfo;
import com.space.enums.LaunchPriority;
import com.space.plugin.PluginRunnable;

public class MainClass extends PluginRunnable {
	
	@Override
	@LaunchInfo(priority = LaunchPriority.NORMAL)
	public void run() {
		CConsole.println("Hello world !");
	}
}