package alien;

import javax.swing.ImageIcon;





public class Alien extends Sprite implements IAlien {

    private Bomb bomb;
    private final String shot = "/spacepix/alien.png";

    
    public Alien() {
        ImageIcon ii = new ImageIcon(this.getClass().getResource(shot));
        setImage(ii.getImage());
        setVisible(true);
    }
    
    public void create(int x, int y) {
        this.x = x;
        this.y = y;
        bomb = new Bomb(x, y);
    }

    /* (non-Javadoc)
	 * @see spaceinvaders.IAlien#act(int)
	 */
    @Override
	public void act(int direction) {
        this.x += direction;
    }

    /* (non-Javadoc)
	 * @see spaceinvaders.IAlien#getBomb()
	 */
    @Override
	public Bomb getBomb() {
        return bomb;
    }
    


    

    public class Bomb extends Sprite {

        private final String bomb = "/spacepix/bomb.png";
        private boolean destroyed;

        public Bomb(int x, int y) {
            setDestroyed(true);
            this.x = x;
            this.y = y;
            ImageIcon ii = new ImageIcon(this.getClass().getResource(bomb));//this.getClass().getResource(bomb));
            setImage(ii.getImage());
        }

        public void setDestroyed(boolean destroyed) {
            this.destroyed = destroyed;
        }

        public boolean isDestroyed() {
            return destroyed;
        }
    }
}