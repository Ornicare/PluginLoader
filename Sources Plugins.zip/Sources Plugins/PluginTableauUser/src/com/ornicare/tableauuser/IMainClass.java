package com.ornicare.tableauuser;

public interface IMainClass {

}