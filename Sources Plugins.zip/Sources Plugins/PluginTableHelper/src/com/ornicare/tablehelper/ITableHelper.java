package com.ornicare.tablehelper;

public interface ITableHelper {

	public abstract int sum();

	public abstract int max();

	public abstract int min();

	public abstract int average();

	public abstract double squareType();

}