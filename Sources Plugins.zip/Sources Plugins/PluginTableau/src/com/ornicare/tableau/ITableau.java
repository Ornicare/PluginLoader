package com.ornicare.tableau;

public interface ITableau {
	public int getSomme();
}