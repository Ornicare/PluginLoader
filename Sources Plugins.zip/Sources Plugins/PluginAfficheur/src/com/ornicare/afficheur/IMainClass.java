package com.ornicare.afficheur;

public interface IMainClass {
	public void affiche(String s);
}
